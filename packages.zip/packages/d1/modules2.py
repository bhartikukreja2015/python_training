
# modules
# python file that contains class def, func def and var assignments
def abc():
    print 'inside abc from modules2 '
    return

x=111
