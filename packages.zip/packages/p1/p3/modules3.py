def pqr():
    print 'inside pqr from modules p3'
    return