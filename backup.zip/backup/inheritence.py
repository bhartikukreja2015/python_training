import os
class A(object):
    'doccccc'
    def __init__(self):  #const
        print 'super const'
        self.ename='xyz'
        self.ecity='hyd'
class B(A):
    #def __init__(self):  #const
     #   print 'const'
        
    def xyz(self):
        self.edsgn='mgr'
        print self.ename,self.ecity
        


# multi level inheritence
class C(B):
    def pqr(self):
        print self.ename,self.ecity,self.edsgn
x=C()
x.xyz()
x.pqr()
