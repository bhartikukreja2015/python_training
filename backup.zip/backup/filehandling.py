import os, sys
os.system('clear')
# create file object
fo=open('myfile.txt','w')

# read inp from key board
print 'enter data'
s=sys.stdin.read()
# will read until u press ctrl+d

# write
fo.write(s)

# close
fo.close()
