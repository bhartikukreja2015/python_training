import os
x=[23,45,6,7]
for m in x:
    print m
for m,n in enumerate(x):
    print m,n
x=[1,2,3,4]
y=['one','two','three','four']
z=['I','II','III','IV']
for p,q,r in zip(x,y,z):
    print p,q,r
    
x=[34,56,78,12,1]
x.sort()
print x
# not good option performance and also prev val order are lost
y=[]
x=[34,56,78,12,1]
for m in sorted(x):
    y.append(m)
    print m
#or
z=sorted(x)
d={'z':3,'y':2,'x':1}
for m in sorted(d):
    print m, d.get(m)
for m in reversed(sorted(d)):
    print m, d.get(m)
# other method
for m,n in sorted(d.iteritems()):
    print m,n
# range n sum
range(10)
range(1,10)
range(1,10,2)
s=sum(range(1,10,2))
print s
