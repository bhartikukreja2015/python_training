import datetime

now = datetime.datetime.now()

print now.hour
print now.strftime('%d-%m-%y')
print now.strftime('%d-%m-%Y')
print now.strftime('%H-%M-%S')
if now.hour<12:
    print 'good morning'
elif now.hour<17:
    print 'good afternoon'
else:
    print 'good evening'
