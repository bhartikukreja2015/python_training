import os


def myfun():
    print'outside'
    def myfunc1():
       print'inside'
       return
    myfunc1()
    print locals()
    return

myfun()




