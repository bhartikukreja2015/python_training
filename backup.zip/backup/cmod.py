import os
class temp2(object): # all classes  are inheriting pre defined class object class
    k=0
    def xin(self): # takes self as first ref, realted to obj
        self.ename=raw_input('ename')
        self.ecity=raw_input('ecity')
    def xout(self):
        temp2.k+=1
        print temp2.k,self.ename,self.ecity
