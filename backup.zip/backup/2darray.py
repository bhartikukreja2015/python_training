m = int(input('number of rows, m = '))
n = int(input('number of columns, n = '))

matrix = [[0 for j in range(n)] for i in range(m)]


for i in range(m):
    for j in range(n):
        matrix[i][j] = int(input('elemnet '))
print(matrix)

# way 2#########
x=[]
k=0
while k<2:
    m=[]
    l=0
    while l<3:
        n=int(raw_input('enter value'))
        m.append(n)
        l+=1
    x.append(m)
    k+=1
print x
