import csv
with open('C2ImportCalEventSample.csv','rb')as f:
    reader = csv.reader(f)
    for row in reader:
        print row


# writing into file
