import os
class vector(object):
    
    def __init__(self,a):  
        print 'super const a'
        self.d=a
        
    def __neg__(self):
        if self.d<0:
            return -(self.d)
        else:
            return (self.d)
def abc():
    print'abc'
# overloaded unary - as absolute abs function

y=vector(12)

print -y
