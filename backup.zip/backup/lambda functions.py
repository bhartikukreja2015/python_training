import os, math

def f1(x,y):
    print x,y
    return
# small func like this consumes lot of memory n time
# better to have func code written at place of call
# i.e. inline func , in python called lambda expressions

f1(5,12)

# lambda func
s=lambda x,y:x+y
res=s(12,10)
print res
print s(range(1,10,2),range(0,10,2))

#square
g = lambda x: x**2
print g(8)
#g(range(10))
#error unsupported for list

# to operate on list
p=lambda x,y,z:x+y+z
print p(1,1,2)
# exp
exp=lambda x: x**2 + 2*x - 5
print exp(2)
############################################
# prime number func
def primeno (n):
    k=2
    s=1
    while k<=math.sqrt(n) and s==1:
        if n%k==0:
            s=0
        k+=1
    return (s)
r=primeno(121)
print 'its prime if 0 -> '
print r
# use as list comprehension for a range
s=[n for n in range(100,1000) if primeno(n)==1]
print s
# move to map n filter
# when u have to give range or list values as arg to func use map, instaed of for loop
# e.g.
def f1(x):
    return x**2
result=map(f1,range(10))
print 'map result'
print result
# chcek odd number
# filter demands condition at end of func
def f2(x):
    return x%2!=0
out=filter(f2,range(1,10))
print out
# list comp for prime 
print filter(primeno,range(100,1000))
# but no condition here
# so change func
def primeno2 (n):
    k=2
    s=1
    while k<=math.sqrt(n) and s==1:
        if n%k==0:
            s=0
        k+=1
    return (s==1)
print filter(primeno2,range(10,30))
# in lambda we cannot use for if break, so map n filter help, map solvers for thing and filter solves conditional part

# online exp to check prime number
primes = range(2, 20)
for i in range(2, 8): 
    primes = filter(lambda x: x == i or x % i, primes)

print 'filter prime res'
print primes

# using lambda inside these
print map(lambda x:x%2!=0, range(1,10))
print filter (lambda x:x%2!=0, range(1,10))
print reduce( (lambda x, y: x * y), [1, 2, 3, 4])
print reduce( (lambda x, y: x / y), [1, 2, 3, 4])
print reduce(lambda x,y:x+y, range(1,10))

# writing reduce function
def myreduce(fnc, seq):
	tally = seq[0]
	for next in seq[1:]:
		tally = fnc(tally, next)
	return tally
print reduce( (lambda x, y: x / y), [1, 2, 3, 4])
