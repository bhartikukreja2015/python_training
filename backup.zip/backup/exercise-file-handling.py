import os, sys, time,json
os.system('clear')
# open file
hashed=0
blank=0
normal=0
# identifu how many normal lines, how many blanjk lines and how many hashed lines
with open('hashcount.txt','r') as fo:
    for m in fo:
        if "#" in m:
            hashed+=1
        if  m in ['\n', '\r\n']:
            blank+=1
        else :
            normal+=1

print hashed, blank, normal
# reverse file and save to another file
with open('hashcount.txt','r') as fo,open('newfile2','w') as fo2:
    s=fo.read()
    rev=s[::-1]
    fo2.write(rev)
print 'file name',fo.name
print 'file mode',fo.mode
print fo.closed,'status'


#writelines expects a list of strings, while write expects a single string
# as array
# write
a=['this\n','is\n','array']
with open('newfile3.txt', 'w') as f:
    f.writelines("%s\n" % l for l in a)
# read file into array 
with open('newfile3.txt','r') as fo:
    a=fo.readlines()
    print a

# modify
with open('hashcount.txt','r+') as fo:
    # to move pointer 10 char ahead
    # windows \n is 2 byte and others 1 byte
    print 'byte no. at beg is' , fo.tell()
    s=fo.read(20)
    t=s.upper
    print 'byte no.after reading is' , fo.tell()
    # fo.seek take 2  args- offset(no. of bytes distance),
    # - whence(0 for beg of file , 1 for current position, 2 for file ending
    
    fo.seek(-20,1)
    # fo.seek(0,0) from beg of file, o0th byte
    # fo.seek(-10,1) from curtrent position go back 10 pts, in this case start
    fo.write(t)
