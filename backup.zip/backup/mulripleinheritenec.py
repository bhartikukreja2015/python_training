import os
class A(object):
    'doccccc'
    def __init__(self):  #const
        print 'super const a'
        self.ename='xyz'
        self.ecity='hyd'
class B(object):
    def __init__(self):  #const
        print 'super const b'
        self.ename='abc'
        self.ecity='hyd'



# multi level inheritence
class C(A,B): # class coming first will hav eits const run
    def pqr(self):
        print self.ename,self.ecity
x=C()
x.pqr()
