import os,filecmp

#x=[12,3,4,6]
#for m in x:
#    print m
#find no of files n dir
fc=0
dc=0
x=os.listdir('.')
for m in x:
    if os.path.isfile(m):
        fc+=1
    elif os.path.isdir(m):
        dc+=1
print '%d files and %d dirs' %(fc,dc)
