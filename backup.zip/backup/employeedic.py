employeedic={'201':['bharti','hyd'],'202':['roma','del'],'203':['pranav','hry']}
print employeedic
employeedic['204']=['adf','afd']
print employeedic
