import logging

logging.basicConfig(filename="test.log",level=logging.DEBUG)
# to get logs in console just remove filename arg
class Pizza():
    def __init__(self,name,price):
        self.name=name
        self.price=price
        logging.debug("pizza created: {} (${})",format)

pizza_01=Pizza("artichoke",15)
