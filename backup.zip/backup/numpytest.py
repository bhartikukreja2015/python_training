Python 2.7.14 (v2.7.14:84471935ed, Sep 16 2017, 20:25:58) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> a=np.arange(15).reshape(3,5)
>>> a
array([[ 0,  1,  2,  3,  4],
       [ 5,  6,  7,  8,  9],
       [10, 11, 12, 13, 14]])
>>> a.shape
(3L, 5L)
>>> b=np.arange(10)
>>> b
array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
>>> a.T
array([[ 0,  5, 10],
       [ 1,  6, 11],
       [ 2,  7, 12],
       [ 3,  8, 13],
       [ 4,  9, 14]])
>>> b.shape
(10L,)
>>> a.ndim
2
>>> a.itemsize
4
>>> a.size
15
>>> a.dtype.name
'int32'
>>> a+np.array([1,2,3,4].reshape(2,2))

Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    a+np.array([1,2,3,4].reshape(2,2))
AttributeError: 'list' object has no attribute 'reshape'
>>> d=np.array([[1,2],[3,4]],dtype=complex)
>>> d
array([[1.+0.j, 2.+0.j],
       [3.+0.j, 4.+0.j]])
>>> np.zeros((3,4))
array([[0., 0., 0., 0.],
       [0., 0., 0., 0.],
       [0., 0., 0., 0.]])
>>> np.ones((2,3,4),dtype=int16)

Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    np.ones((2,3,4),dtype=int16)
NameError: name 'int16' is not defined
>>> np.ones((2,3,4),np.dtype=int16)
SyntaxError: keyword can't be an expression
>>> np.ones((2,3,4),dtype=np.int16)
array([[[1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1]],

       [[1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1]]], dtype=int16)
>>> a=np.array([1,2,3,4,5,6]).reshape(2,3)
>>> b=np.array([1,1,2,2,3,3]).reshape(2,3)
>>> c=a*b
>>> c
array([[ 1,  2,  6],
       [ 8, 15, 18]])
>>> d=a.dotb

Traceback (most recent call last):
  File "<pyshell#24>", line 1, in <module>
    d=a.dotb
AttributeError: 'numpy.ndarray' object has no attribute 'dotb'
>>> d=a.dot(b)

Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    d=a.dot(b)
ValueError: shapes (2,3) and (2,3) not aligned: 3 (dim 1) != 2 (dim 0)
>>> a
array([[1, 2, 3],
       [4, 5, 6]])
>>> b=np.array([1,1,2,2,3,3]).reshape(3,2)
