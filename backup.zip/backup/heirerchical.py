import os
class A(object):
    'doccccc'
    def __init__(self):  #const
        print 'super const a'
        self.ename='xyz'
        self.ecity='hyd'
class B(A):
    def __init__(self):  #const
        print 'const b'
        self.ename='abc'
        self.ecity='hyd'
    def xyz(self):
        print self.ename,self.ecity


# multi level inheritence
class C(A): # class coming first will hav eits const run
    def pqr(self):
        print self.ename,self.ecity
x=C()
x.pqr()
x=B()
x.xyz()
