import os
class temp2(object):
    'doccccc'
    k=111
    __kp=111
    def xin(self): # takes self as first ref, realted to obj
        self.ename='xyz'
        self.ecity='hyd'
        self.__ecityp='hyd'
    def xyz(self):
        print self.ename,self.ecity
# usually var are privet and methods are public
# all var are default public in python
# but private var cannot be inherited- prob
# to make private have __ in front
x = temp2()
x.xin()
x.xyz()
print x.ename, x.ecity, x.k
#print x.__ecityp # cannot be accesed
#print temp2.__kp
#print x.__kp


# object level att
print hasattr(x,'ename')
setattr(x,'edsgn','mgr')
print x.edsgn
delattr(x,'ename')
#print x.ename # cannot access now

# class level info
print 'name of class' , temp2.__name__
print 'doc string' , temp2.__doc__
print 'dictionary' , temp2.__dict__
print 'module' , temp2.__module__
print 'base' , temp2.__bases__
