import os
class vector(object):
    def __init__(self,a):  
        print 'super const a'
        self.d=a
        
    def __add__(self,other): # magic functions 
        abc()
        self.d.update(other.d) # method to update elements in dictionary
        return self.d
def abc():
    print'abc'

d1={'x':1,'y':2,'z':3}
d2={'a':4,'b':5,'c':6}

x=vector(d1)
y=vector(d2)

z=x+y

print z
#def abc(): #wont work here, it should be defined brfore making obj
#    print'abc'
# no _ public
# 1 _  protected (can be inherited )
# 2 _ private
