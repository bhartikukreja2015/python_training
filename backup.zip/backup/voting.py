import os
MyList=[]
a=0
while a < 5:
    n=raw_input('enter name')
    MyList.append(n)
    a+=1


my_dict = {i:MyList.count(i) for i in MyList}
print my_dict


# method 2
x=[]
k=1
while k<=10:
    n=raw_input('enter name')
    x.append(n)
    k+=1
y=set(x)
for m in y:
    print m,x.count(m)
