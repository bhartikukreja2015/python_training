import os
x=['keyboard','monitor','cd-rom','usb','printer']
for m in x:
    if(len(m)>5):
        print m
# its list comprehension
s=[m for m in x if len(m)>5]
print s

# position also'

t=[(m,n) for m,n in enumerate(x) if len(n)>5]
print t

#
for m in range (1,4):
    for n in range(1,3):
        if m!=n:
            print m,n

# in list comp
s=[(m,n) for m in range(1,4) for n in range(1,3) if m!=n]
print s
