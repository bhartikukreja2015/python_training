# save temp class in cmod.py
# read object
import os, pickle
from cmod import temp2
with open('objectdata','r')as fo:
    data =pickle.load(fo)

for m in data:
    m.xout()
    
