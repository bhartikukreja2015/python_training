# pre defined and usr level

# we code user level
import os,sys

try:
    n=int(raw_input("enter number"))
except ValueError:
    print 'invalid value erorr'
    print sys.exc_info()[1]

except:
    print 'invalid'
    print sys.exc_info()[1]
k=1
while k<3:
    print 'python'
    k+=1
