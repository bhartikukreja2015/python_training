import p1
# importing connected module function

p1.abc()
p1.pqr()

