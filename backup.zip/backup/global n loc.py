import os

# local n global 
k=111
print k
def myfun ():
    k=222
    print k
    global m 
    m=k+globals()['k']
    print m
    print locals()
    print globals()
    return

myfun()
print k
#print m error without global dec
print m


