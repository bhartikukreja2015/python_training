import os
basic = float(raw_input('enter basic'))
hra =.4*basic
da =.2*basic
gross =(basic+hra+da)
ded =.1*gross
net =gross-ded
print 'basic=	%.2f 	hra=	%.2f'%(basic,hra)
