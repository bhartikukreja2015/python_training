import os,filecmp
# find total size of python file sin current dir
grandSize=0
x=os.listdir('.')
for m in x:
    if os.path.isfile(m) and m[-3:]=='.py':
        t=os.path.getsize(m)
        grandSize+=t
  
print '%d file size' %(grandSize)
