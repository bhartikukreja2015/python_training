import os
string='abvcvv'
y=list(string)
temp = []
for m in y:
    if m in temp:
        print'dup'
    else:
        temp.append(m)

print temp

# optimized
s='inpjhjjjj'
t=''
result=[t+m for m in s if m not in t]
print result
