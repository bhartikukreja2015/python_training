import os, sys
os.system('clear')
# open file
with open('newfile','w') as fo:
    print 'enterd data'
    s=sys.stdin.read()
    fo.write(s)

# no need to close, as u come out of wiith it closes
# with is context manager
# it does consumes memory
