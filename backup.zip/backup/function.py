import os

# function definition

def myfun ():
    'my first functions document string'
    k=1
    while k<=3:
        print 'PYthon'
        k+=1
    return
print 'working with user defined func'
print myfun.__doc__
myfun()
# function working like first class
x=myfun
del myfun

x()
print 'DONE'

#########second prog

# function with arg and return values
def myfuncc(x):
    if type(x) is dict:
        for m,n in sorted(x.iteritems()):
            print m,n
    else:
        print'data not compatible'
    return
d={'x':1,'f':2,'z':3}
myfuncc(d)
myfuncc(10)

#3rd prog
def myfuncct(x):
    e=sorted(x.iteritems())
    return e
d={'x':1,'f':2,'z':3}
r=myfuncct(d)
print r

# 4th prog
def myfuncs(x,y,z):
    return sum([x,y,z])
s=myfuncs(12,13,14)
print s

# 5th prog
# default value should always come to right side
def myfuncs2(x,y,z=121):
    return sum([x,y,z])
s=myfuncs2(12,13)
s2=myfuncs2(12,13,14)
print s
print s2

#6th prog func with  specific args -----best way to avoid confusion
def myfuncs3(x,y,z):
    return sum([x,y,z])
s=myfuncs3(x=12,z=13,y=2)
print s

#7th prog func with var length arg 0 or many arg can be passed
def myfvar(*p):
    # p is tuple, func will have tuple can have 0 or many elements also 
    return sum((p))
s=myfvar(1,2,3,4,5)
s1=myfvar()
print s
print s1

#8th prog func with var length arg and specific names and values
def myfvar2(**z):
    # p is dictionary, func will have many key value pairs
    for m,n in sorted(z.iteritems()):
        print m,n
    return 
myfvar2(x=1,y=2,z=3)



