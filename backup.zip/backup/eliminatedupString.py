from collections import OrderedDict
foo = "mppsamt"
print "".join(OrderedDict.fromkeys(foo))
