# pre defined and usr level

# we code user level
import os,sys

class myerror(Exception):
    pass
class toosmall(myerror):
    pass
class toolarge(myerror):
    pass
while True:
    try:
        n=int(raw_input('enter val'))
        if n<100:
            raise toosmall
        if n>100:
            raise toolarge
        elif n==100:
          print 'correct'
          break
    except toosmall:
        print 'entered too small'
    except toolarge:
        print 'entered too lareg'
    except:
        print 'unknown exception'
