import os
class temp2(object):
    'doccccc'
    def __init__(self):  #const
        self.ename='xyz'
        self.ecity='hyd'
    def xyz(self):
        print self.ename,self.ecity
    def __del__(self): # automatically called, no need to run it
        print self.__class__.__name__, 'object destroyed'

x=temp2()
x.xyz()

