import os
n=raw_input('enter name')

if os.path.isfile(n) and n[-3:]=='.py':
    print '%s is a py file'% (n)
    s=os.path.getsize(n)
    print '%s has %d bytes'% (n,s)
else :
    print 'invalid entry'

