import os,filecmp

m = raw_input('enter first file name')
n = raw_input('enter second file name')

if filecmp.cmp(m,n):
    print 'yes'
else:
    print 'no'
