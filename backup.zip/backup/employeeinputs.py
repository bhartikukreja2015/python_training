import os,datetime
eno=int(raw_input('enter eno'))
ename=raw_input('e name')
edate=raw_input('date dd-mm-yyy')
xdate=datetime.datetime.strptime(edate,'%d-%m-%Y')
print xdate
print type(xdate)
print eno, ename, edate
