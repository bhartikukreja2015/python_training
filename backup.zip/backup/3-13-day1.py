Python 2.7.14 (v2.7.14:84471935ed, Sep 16 2017, 20:25:58) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
===================== RESTART: D:\backup\employeedic.py =====================
>>> 
===================== RESTART: D:\backup\employeedic.py =====================
{'201': ['bharti', 'hyd'], '203': ['pranav', 'hry'], '202': ['roma', 'del']}
>>> 
===================== RESTART: D:\backup\employeedic.py =====================
{'201': ['bharti', 'hyd'], '203': ['pranav', 'hry'], '202': ['roma', 'del']}
>>> 
===================== RESTART: D:\backup\employeedic.py =====================
{'201': ['bharti', 'hyd'], '203': ['pranav', 'hry'], '202': ['roma', 'del']}
>>> 
===================== RESTART: D:\backup\employeedic.py =====================
{'201': ['bharti', 'hyd'], '203': ['pranav', 'hry'], '202': ['roma', 'del']}
{'201': ['bharti', 'hyd'], '203': ['pranav', 'hry'], '202': ['roma', 'del'], '204': ['adf', 'afd']}
>>> 
======================= RESTART: D:/backup/2darray.py =======================
number of rows, m = 2
number of columns, n = 3
1 2 3

Traceback (most recent call last):
  File "D:/backup/2darray.py", line 8, in <module>
    matrix[i] = list(input().strip())
  File "<string>", line 1
    1 2 3
      ^
SyntaxError: invalid syntax
>>> 
======================= RESTART: D:/backup/2darray.py =======================
number of rows, m = 2
number of columns, n = 3
elemnet 1
elemnet 2
elemnet 3
elemnet 4
elemnet 5
elemnet 6
[[1, 2, 3], [4, 5, 6]]
>>> x=[1,2,2,3,4,4,5,5,8,6,5]
>>> y=set(x)
>>> y
set([1, 2, 3, 4, 5, 6, 8])
>>> y.updtae([a,b,c,d,e,f])

Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    y.updtae([a,b,c,d,e,f])
AttributeError: 'set' object has no attribute 'updtae'
>>> y.update([a,b,c,d,e,f])

Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    y.update([a,b,c,d,e,f])
NameError: name 'a' is not defined
>>> y.update(['a','b','c','d','e','f'])
>>> 
>>> y
set(['a', 1, 2, 3, 4, 5, 6, 'f', 8, 'c', 'b', 'e', 'd'])
>>> y.add("abc")
>>> y
set(['a', 1, 2, 3, 4, 5, 6, 'f', 8, 'c', 'abc', 'b', 'e', 'd'])
>>> y.clear()
>>> y
set([])
>>> y=set([1,2,2,3,4,4,5,5,8,6,5])
>>> y
set([1, 2, 3, 4, 5, 6, 8])
>>> b=y.copy()
>>> b
set([1, 2, 3, 4, 5, 6, 8])
>>> b.discard(3)
>>> y.union(b)
set([1, 2, 3, 4, 5, 6, 8])
>>> y|b
set([1, 2, 3, 4, 5, 6, 8])
>>> y.intersection(b)
set([1, 2, 4, 5, 6, 8])
>>> y&b
set([1, 2, 4, 5, 6, 8])
>>> y.difference(b)
set([3])
>>> y^b
set([3])
>>> y-b
set([3])
>>> y.symmetric_difference(b)
set([3])
>>> p1=set([1,2])
>>> p1.issubset(s1)

Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    p1.issubset(s1)
NameError: name 's1' is not defined
>>> p1.issubset(y)
True
>>> y.issup

Traceback (most recent call last):
  File "<pyshell#28>", line 1, in <module>
    y.issup
AttributeError: 'set' object has no attribute 'issup'
>>> y.issuperset(p1)
True
>>> 
======================== RESTART: D:/backup/voting.py ========================

Traceback (most recent call last):
  File "D:/backup/voting.py", line 3, in <module>
    while a < 15:
NameError: name 'a' is not defined
>>> 
======================== RESTART: D:/backup/voting.py ========================
enter namea
enter namea
enter nameb
enter nameb
enter namec
{'a': 2, 'c': 1, 'b': 2}
>>> 
======================== RESTART: D:/backup/voting.py ========================
enter name1
enter name1
enter name1
enter name2
enter name2
{'1': 3, '2': 2}
enter namea
enter namea
enter namea
enter namea
enter nameb
enter nameb
enter nameb
enter namec
enter namec
enter namec
a 4
c 3
b 3
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
>>> y=sorted(x)
>>> y
[1, 12, 34, 56, 78]
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
x 1
y 2
z 3
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
x 3
y 2
z 1
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
x 1
y 2
z 3
z 3
y 2
x 1
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
x 1
y 2
z 3
z 3
y 2
x 1
x 1
y 2
z 3
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
x 1
y 2
z 3
z 3
y 2
x 1
x 1
y 2
z 3
>>> 
====================== RESTART: D:/backup/iteration.py ======================
23
45
6
7
0 23
1 45
2 6
3 7
1 one I
2 two II
3 three III
4 four IV
[1, 12, 34, 56, 78]
1
12
34
56
78
x 1
y 2
z 3
z 3
y 2
x 1
x 1
y 2
z 3
25
>>> 
================== RESTART: D:/backup/listcomprehension.py ==================
keyboard
monitor
cd-rom
printer
>>> 
================== RESTART: D:/backup/listcomprehension.py ==================
keyboard
monitor
cd-rom
printer
>>> 
================== RESTART: D:/backup/listcomprehension.py ==================
keyboard
monitor
cd-rom
printer
['keyboard', 'monitor', 'cd-rom', 'printer']
>>> 
================== RESTART: D:/backup/listcomprehension.py ==================
keyboard
monitor
cd-rom
printer
['keyboard', 'monitor', 'cd-rom', 'printer']

Traceback (most recent call last):
  File "D:/backup/listcomprehension.py", line 12, in <module>
    t=[(m,n) for m,n in enumerate(x) if len(m)>5]
TypeError: object of type 'int' has no len()
>>> 
================== RESTART: D:/backup/listcomprehension.py ==================
keyboard
monitor
cd-rom
printer
['keyboard', 'monitor', 'cd-rom', 'printer']
[(0, 'keyboard'), (1, 'monitor'), (2, 'cd-rom'), (4, 'printer')]
>>> for m in range (1,4):
    for n in range(1,3):
        if m!=n:
            print m,n

            
1 2
2 1
3 1
3 2
>>> 
================== RESTART: D:/backup/listcomprehension.py ==================
keyboard
monitor
cd-rom
printer
['keyboard', 'monitor', 'cd-rom', 'printer']
[(0, 'keyboard'), (1, 'monitor'), (2, 'cd-rom'), (4, 'printer')]
1 2
2 1
3 1
3 2
[(1, 2), (2, 1), (3, 1), (3, 2)]
>>> 
