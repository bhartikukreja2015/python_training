
# modules
# python file that contains class def, func def and var assignments
def abc():
    print 'inside abc'
    return
def pqr():
    print 'inside pqr'
    return
def xyz():
    print 'inside xyz'
    return
x=111
y='computer'
# how to use these functions in outside programs
# we have to take these def and store in a file to make mosule/lib
# this lib will have func definitions, class def and variables assignments.
# u can include that lib file n use it 

# we will have to save file in same  folder as exceution file
# when we import a module, the module gets compiled and a complied version file.pyc is made by python
# when we make any change in modules file, the pyc file will be updated automatically
# module files are compiled
# without source .pyc will work but avoid it bcoz u cannot make changes
# also we cannot review source then

# when u import module all def are loaded in memory , out of those we will call 1 or 2
# so that's memory wastage
# try selective import instead

# from modules import abc,x chcek in trymod2
