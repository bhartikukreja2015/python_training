import os,filecmp,glob
# find total size of python file sin current dir
x=glob.glob('*.py')
grandSize=0
x=os.listdir('.')
for m in x:
    grandSize+=os.path.getsize(m)
  
print '%d file size' %(grandSize)
