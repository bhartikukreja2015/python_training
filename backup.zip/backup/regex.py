import os,re,sys
x='this is python programming'
# search for python in string
m=re.search('python',x)
if m:
    print x
# if expression fails m will be none
# else if successful m will be created

# get all lines having python in them 
with open('python_regex.txt') as fo:
    for m in fo:
        r=re.search('python',m)
        if r :
            sys.stdout.write(m)

#to search in beg and ignore case
            #r=re.search('^python',m,re.I)
print 'find python and how many times python in every line'
import os,re,sys
x='this is apython programming wxpython good python course'
m=re.findall('python',x)
print m
m2=re.findall('[a-z]*python[a-z]*',x)
print m2
print len(m2)

print '-------final prog'
with open('python_regex.txt') as fo:
    for m in fo:
        r=re.findall('[a-z]*python[a-z]*',m)
        if r :
            print len(r),m

#pick cust name n city from dir
# use grouping for this
x='AAA 0111-98690 faridabad'
m=re.search('([A-Z]+) ([0-9]+)-([0-9]+) ([a-z]+)',x)
print m.group(1,4)
# this exp means find A to Z + means keep on taking after ( its space , so take till u find space
# then 0-9till u find - and then 0 to 9
# the prod is this reg ex is very big and takes lot time
# so compile this reg ex fist and it works with good speed
# but clear buffer of reg expression time to time using purge
s='([A-Z]+) ([0-9]+)-([0-9]+) ([a-z]+)'
t=re.compile(s)
m=re.search(t,x)
print m.group(1,4)
re.purge()

# lets compile all this code for a file
print 'compiled prog'
s='([A-Z]+) ([0-9]+)-([0-9]+) ([a-z]+)'
t=re.compile(s)
with open('python_regex2.txt') as fo:
    for m in fo:
        r=re.search(t,m)
        if r:
            print r.group(1,4)
        re.purge()
        
# pickup name n phoen nos
print 'non formated name and num prog'
s='([a-z ]+)([A-Z]+)([a-z ]+)([0-9]+)'
#[a-z ]+ means all lower case chars with space until upper case is found
# no spaces between braces
t=re.compile(s)
with open('python_regex3.txt') as fo:
    for m in fo:
        r=re.search(t,m)
        if r:
            print r.group(2,4)
        re.purge()
# match always looks a beg of line only
x='this is python programming'
m2=re.match('python',x)

#3 substitue
p=re.sub('python',"PYTHON",x)
print p
