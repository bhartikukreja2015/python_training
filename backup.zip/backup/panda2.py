# pandas
import os,pandas as pd
import openpyxl
d={}
k=1
while k<=2:
    key=raw_input('kepy pls')
    l=1
    x=[]
    while l<=3:
        s=raw_input('name pls')
        x.append(s)
        l+=1
    d[key]=x
    k+=1
df=pd.DataFrame(d)
print df

# write csv
df.to_csv('mycsv.csv',sep='\t',encoding='utf-8')

# write excel
p=pd.ExcelWriter('myexcel.xlsx',engine='openpyxl')
df.to_excel(p,sheet_name='sheet 1')
p.save()
