from modules import abc as abc1,x
from modules2 import abc as abc2
# here latest one will execute
#abc()
print x
# so try aliases
abc1()
abc2()

#what is modules are in some other folders 
# create python path and execute batch file for setting python path
# help('modules')
# 3 import os, dir os
# help(os.system)

# to install package in python
# pip
# easy_install
# first install pi or easy_install to use them

