import os,glob
# find total size of python file sin current dir
# list comprehension
grandSize=sum([os.path.getsize(m) for m in glob.glob('*.py')])

print '%d file size' %(grandSize)
