import os

# pass function to func as arguments\
def f1(a,b):
    return (a+b)
def f2(a,b):
    return(a-b)
def myfun(p,q):
    r1=p(12,10)
    r2=q(12,10)
    return r1+r2


s=myfun(f1,f2)
print s




