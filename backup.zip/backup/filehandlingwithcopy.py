import os, sys, time,json
os.system('clear')
# open file
#default i sread mode, even if u dont specify it take r
with open('newfile','r') as fo1, open('newfile2','w') as fo2:
    s=fo1.read()
    # for only 10-20 chars use read(10)
    fo2.write(s)

## using command line arguments for this 
#with open(sys.argv[1]) as fo1, open(sys.argv[2],'w') as fo2:
 #   s=fo1.read()
    # for only 10-20 chars use read(10)
  #  fo2.write(s)
# argv[0] is prog code itself


# display contents of file

with open('newfile') as fo1:
    s=fo1.read()
    sys.stdout.write(s)
# to process line by line
print'to process line by line'
with open('newfile') as fo:
    for m in fo:
        sys.stdout.write(m)
        print ('line..')
        time.sleep(2)

# write dictoinary to a json file

emp=dict()

n=int(raw_input('how many'))
k=1
while k<=n:
    # input data
    id=int(raw_input('give id ')) 
    emp['id']=(raw_input('give info ')) 
    k+=1
with open('records','w') as fo:
    json.dump(emp,fo)

# read json file
with open('records','r') as fo:
  emp=json.load(fo)
for m ,n in sorted(emp.iteritems()):
      print m,n
