import modules

modules.abc()
modules.pqr()
modules.xyz()
print modules.x, modules.y
