# oops in python
# topics
#   class var and class methods
#   object var and obj methods
#   class level n obj level attributes
#   const destructors
#   private n public methods
#   inheritence single multilevel multiple heirarchical
#   operator over loading
#   other features
#--------------------------------------------------------------------------#
import os, pickle
#class var and class methods
class temp(object): # all classes  are inheriting pre defined class object class
    eno=111  #class variable
    @classmethod  # decorator
    def abc(temp):  #class method should have class name as first arg
        print temp.eno
    @classmethod  
    def pqr(cls):  #class method can also have cls instaed of name
        print 'class level method cls'
        print cls.eno
    def stu(self): # takes self as first ref, realted to obj
        self.ename='xyz' # object var, they come into existance wen object is created
        self.ecity='hyd'
    def xyz(self):
        print self.ename,self.ecity
        
print temp.eno  # class var reffered through class name
temp.abc() # for class level methods u need not have its object created
temp.pqr()

#object level calling
x=temp() # creating instance of temp class
x.stu()
x.xyz()
x.abc()# also works

# how to avoid global access of var

#---------------------------------------------------------------------------#
class temp2(object): # all classes  are inheriting pre defined class object class
    k=0
    def xin(self): # takes self as first ref, realted to obj
        self.ename=raw_input('ename')
        self.ecity=raw_input('ecity')
    def xout(self):
        temp2.k+=1
        print temp2.k,self.ename,self.ecity
# creating the array
data=[]
p=0
while p<3:
    data.append(temp2()) # data is now array of 3 objects
    p+=1
# execute object methonds
q=0
while q<3:
    data[q].xin()
    q+=1
r=0
while r<3:
    data[r].xout()
    r+=1
# save objects - object serialization
with open('objectdata','w') as fo:
    pickle.dump(data,fo)

# read object
import os, pickle
from cmod import temp
with open('objectdata','r')as fo:
    data =pickle.load(fo)

for m in data:
    m.xout()
    
